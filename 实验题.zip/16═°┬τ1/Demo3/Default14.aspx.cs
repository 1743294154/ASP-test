﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default14 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            DropDownList1.Items.Add("足球");
            DropDownList1.Items.Add("篮球");
            DropDownList1.Items.Add("排球");
            DropDownList1.Items.Add("网球");
            DropDownList1.Items.Add("羽毛球");
            DropDownList1.Items.Add("乒乓球");
        }
    }

    //下拉列表框的选中项改变事件，当下拉框选中的项目发生变化的产生

    //默认情况下，按钮的单击事件会引起页面的回发，相应的代码会被执行
    //其它控件的事件，默认不会引起页面回发
    //如果希望其它控件的事件要引起回发，可以设置控件的AutoPostBack为true
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label1.Text = DropDownList1.SelectedValue;
    }
}