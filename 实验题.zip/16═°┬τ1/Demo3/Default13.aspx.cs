﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default13 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.Items.Add("韩国");
            DropDownList1.Items.Add("日本");
            DropDownList1.Items.Add("泰国");
            DropDownList1.Items.Add("菲律宾");
            DropDownList1.Items.Add("马来西亚");
            DropDownList1.Items.Add("越南");
            DropDownList1.Items.Add("俄罗斯");
        }
    }
    //对象的三要素：属性、事件、方法
    protected void Button1_Click(object sender, EventArgs e)
    {
        //将左边下拉框选中项移动到右边下拉框
        DropDownList2.Items.Add(DropDownList1.SelectedValue);
        DropDownList1.Items.Remove(DropDownList1.SelectedItem);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //将右边下拉框选中项移动到左边下拉框
        DropDownList1.Items.Add(DropDownList2.SelectedValue);
        DropDownList2.Items.Remove(DropDownList2.SelectedItem);
    }
}