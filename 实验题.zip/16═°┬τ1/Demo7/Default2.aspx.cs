﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    int a, b, c;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //给变量a和b赋值
        a = Convert.ToInt32(TextBox1.Text);
        b = Convert.ToInt32(TextBox2.Text);
        //将需要保持的数据放入ViewState
        ViewState["a"] = a;
        ViewState["b"] = b;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        //计算a+b并显示
        //从ViewState中取出a和b的值
        a = Convert.ToInt32(ViewState["a"]);
        b = Convert.ToInt32(ViewState["b"]);
        c=a+b;
        Label1.Text = Convert.ToString(c);
    }
}