﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if(DateTime.Now.Hour<=12)
        {
            TextBox1.Text = "上午好！";
        }
        else
        {
            TextBox1.Text = "下午好！";
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if(DateTime.Now.Hour<6)
        {
            TextBox2.Text="凌晨不睡觉吗？";
        }
        else if(DateTime.Now.Hour<=12)
        {
            TextBox2.Text="上午好！";
        }
        else if(DateTime.Now.Hour<19)
        {
            TextBox2.Text = "下午好！";
        }
        else
        {
            TextBox2.Text = "滚去睡觉！";
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        switch(DateTime.Now.DayOfWeek)
        {
            case DayOfWeek.Monday:
                TextBox3.Text = "新的一周开始了！";
                break;
            case DayOfWeek.Tuesday:
                TextBox3.Text = "下午不上课！";
                break;
            case DayOfWeek.Wednesday:
                TextBox3.Text = "补课！";
                break;
            case DayOfWeek.Thursday:
                TextBox3.Text = "本来就要上课！";
                break;
            case DayOfWeek.Friday:
                TextBox3.Text = "要休息啦！";
                break;
            case DayOfWeek.Saturday:
            case DayOfWeek.Sunday:
                TextBox3.Text = "休息！";
                break;
        }

    }
}