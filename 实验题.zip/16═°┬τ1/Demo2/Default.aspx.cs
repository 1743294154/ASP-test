﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //当Button1点击时会执行的事件代码
    protected void Button1_Click(object sender, EventArgs e)
    {
        //变量及数据类型
        int a, b, c=84;
        a = 79;
        float x = 3.14f;
        Single y = 3.14f;
        double d = 3.14;

        char c1, c2 = '0';
        string s1;
        string s2 = "Hello,C#!";
        string s3 = "6";
        string s4 = "";

        bool f1 = true, f2 = false;

        DateTime t = DateTime.Now;

        TextBox1.Text = Convert.ToString(t);
    }

    //当Button2点击时会执行的事件代码
    protected void Button2_Click(object sender, EventArgs e)
    {
        int a = 89, b = 73;
        int c = a + b;
        TextBox2.Text = Convert.ToString(c);

        float x = a + b;
        double z = 87.9999888877776666;
        float y = Convert.ToSingle(z);

        string s = "973";
        int t = Convert.ToInt32(s);
        
        //数学函数
        Math.Sin(23.9);
        double d = Math.E;
        //字符串函数
        string s2 = "Hello,China!";
        int l = s2.Length;
    }
}
